# `fefferman-clay-navier-stokes` — Formalizing Fefferman's Official Periodic Navier–Stokes Problem (B) in Lean 4: Global Linear Strain Exclusion on $\mathbb{T}^3$, Biot–Savart Direction Depletion Identities, and Conditional Reductions via Beale–Kato–Majda

[![certify.yml](https://github.com/BenFrohman/fefferman-clay-navier-stokes/actions/workflows/certify.yml/badge.svg?branch=main)](https://github.com/BenFrohman/fefferman-clay-navier-stokes/actions/workflows/certify.yml)

**Author:** Benjamin Stanley Frohman ([ORCID: 0009-0006-7068-3718](https://orcid.org/0009-0006-7068-3718))  
**Zenodo DOI (v1.1.0):** [`10.5281/zenodo.23717083`](https://doi.org/10.5281/zenodo.23717083) | **Concept DOI:** [`10.5281/zenodo.23652840`](https://doi.org/10.5281/zenodo.23652840) | **v1.0.0 DOI:** [`10.5281/zenodo.23652841`](https://doi.org/10.5281/zenodo.23652841)  
**License:** Apache-2.0 (`Copyright (c) 2026 Benjamin Stanley Frohman`)  
**Toolchain:** `leanprover/lean4:v4.30.0-rc1` + Mathlib 4 (`2643` build jobs, **224 theorem/lemma declarations in source at commit `34e5a7f`**, **0 `sorry`**, **0 non-standard axioms**)  
**Paper PDF:** [`Fefferman_Clay_Navier_Stokes_Periodic_Regularity_2026.pdf`](Fefferman_Clay_Navier_Stokes_Periodic_Regularity_2026.pdf)

---

## Main Theorem (proved reduction)

`clay_reduces_to_direction_curvature_bound` (Lean 4 + Mathlib, `0 sorry`, axioms `[propext, Classical.choice, Quot.sound]`):

> For every ν > 0, assuming the classical periodic Beale–Kato–Majda continuation principle `PeriodicBKMContinuation ν` (a published theorem, Kato 1972 / Beale–Kato–Majda 1984, **not** formalized here and therefore an explicit hypothesis), the named estimate `DirectionCurvatureBound ν` implies Fefferman's exact periodic Clay statement `Clay_B_exact ν`.

- `DirectionCurvatureBound ν` (high-set direction-curvature / cubic depletion bound `M' ≤ C M² − κ M³`) is the single named **open** estimate (conjecture). It is **not** proved.
- Periodic Beale–Kato–Majda step. `periodicTstar ν u₀` is the supremum in `EReal` of the horizons on which a periodic smooth solution from `u₀` exists. Proved: `periodicTstar_eq_top_of_bkm`, `periodicGlobalOfTstarTop` (the global step, now a theorem rather than a hypothesis) and `clay_B_exact_of_periodic_bkm`, which derives `Clay_B_exact ν` from `PeriodicLocalExistence ν`, `PeriodicMaximalSolution ν`, `PeriodicBKMCriterion ν` (classical: Kato 1972, uniqueness and gluing, Beale–Kato–Majda 1984; not formalized here, explicit hypotheses) and `PeriodicBKMIntegrability ν` (open: `‖ω(t)‖_∞` integrable on every `[0,T]` along the maximal solution). `PeriodicMaximalSolution` is proved from an energy-uniqueness hypothesis in the private companion repository `periodic-ns-classical-continuation`.
- Correction to the definitions. Earlier, `IsPeriodicSmoothSolutionOn` also required `IsPhysicalNSSolution u` (square-integrable over all of ℝ³), which no nonzero periodic field satisfies, and `IsPeriodicMaximalSolution` also asked for solutions on horizons `T ≤ 0`. With those definitions `PeriodicLocalExistence ν` and `PeriodicMaximalSolution ν` were false for every `ν > 0`, so the earlier `clay_B_exact_of_periodic_bkm` had hypotheses that could not all hold. Now the ℝ³ clause is dropped (the energy over one period cell is finite automatically) and maximality is required only for `0 < T`. The old definitions are kept with the suffix `Original`, and the refutations are proved: `not_periodicLocalExistenceOriginal`, `not_periodicMaximalSolutionOriginal`.
- Vorticity bounds over existing solutions. `PeriodicTetherClosingBound`, `PeriodicFiniteTimeVorticityBound` and the matching continuation Props `PeriodicBKMContinuation`, `PeriodicBKMContinuationFiniteTime` quantify only over solutions that already exist on `[0,T]`. `periodicFiniteTimeBound_vacuous` proves the bound holds with `C = 0` on any horizon with no solution, so in `clay_B_exact_of_periodic_tether_bound`, `clay_B_exact_of_torus_direction_depletion` and `clay_B_exact_of_periodic_finite_time_bound_scaffold` the continuation hypothesis carries the whole of Statement (B). These are kept as scaffolding, together with `periodicFiniteTimeVorticityBound_of_uniform` and `periodicBKMContinuation_of_finiteTime_scaffold`.
- The Clay problem is **not** claimed solved. The converse (`Clay_B_exact → DirectionCurvatureBound`) is **not** proved.

**Main Theorem A (unconditional supporting facts):** attained-maximum ⇒ `BddAbove` and sup-norm equality; Bochner and polar Pythagoras identities, now *derived* from `HasDerivAt` along coordinate lines (`Stage6Calculus.lean`); the near/far cutoff absorption algebra; Burgers-strain exclusion on 𝕋³; the comparison-ODE ceiling; and a genuinely non-constant exact periodic shear Beltrami mode `e^{-4π²νt}(sin 2πz, cos 2πz, 0)` checked component-wise.

## Single-Sentence Final Product Form of the Stated Problem and Proved Exact Reductions (`FinalProductTheorem.lean`)

In [`FeffermanClayNS/FinalProductTheorem.lean`](FeffermanClayNS/FinalProductTheorem.lean), the unconditional geometric, kinematic, Bochner–polar and ODE comparison theorems and the conditional reduction theorems for **Fefferman's Official Periodic Navier–Stokes Problem (B)** are packaged into the single machine-checked 5-conjunct product theorem `fefferman_periodic_ns_exact_reduction_product_theorem` (`Q₁(ν) ∧ Q₂ ∧ Q₃ ∧ Q₄ ∧ Q₅(ν)`), verified with `0 sorry` and standard axioms `[propext, Classical.choice, Quot.sound]`:

### 1. Single-Sentence English Prose Statement
> **Theorem (`fefferman_periodic_ns_exact_reduction_product_theorem`):** For every viscosity $\nu \in \mathbb{R}$ on the 3-torus $\mathbb{T}^3 = \mathbb{R}^3/\mathbb{Z}^3$, **(Q₁)** spatial $\mathbb{Z}^3$-periodicity is equivalent to invariance under the three unit coordinate shifts $f(x+e_j)=f(x)$, and Fefferman's energy-bounded periodic statement implies his exact periodic statement ($\mathrm{Clay\_B\_exact\_with\_energy}(\nu) \implies \mathrm{Clay\_B\_exact}(\nu)$); **(Q₂)** every $\mathbb{Z}^3$-periodic linear map $L : \mathbb{R}^3 \to \mathbb{R}^3$ vanishes identically ($L = 0$), excluding any non-zero global linear Burgers background strain $\mathrm{diag}(-\alpha/2,-\alpha/2,\alpha)x$ ($\alpha \neq 0$) on $\mathbb{T}^3$; **(Q₃)** the Biot–Savart vortex-stretching determinant obeys $\det(\omega(y),z,\omega(x)) = \det(\omega(y)-\omega(x),z,\omega(x))$ and vanishes under collinear alignment $\omega(y)=c\,\omega(x)$, while under parabolic rescaling $u_\lambda(x,t)=\lambda u(\lambda x,\lambda^2 t)$ both cubic stretching $C_{\mathrm{CZ}}|\omega_\lambda|^3$ and viscous direction-curvature dissipation $\nu|\omega_\lambda|^2|\nabla\hat{\xi}_\lambda|^2$ scale homogeneously as $\lambda^6$; **(Q₄)** at a spatial maximum $x_{\max}$ where $\langle\omega,(\omega\cdot\nabla)u\rangle \le C_{\mathrm{CZ}}M^3$, $\nu\langle\omega,\Delta\omega\rangle \le -\nu M^2|\nabla\hat{\xi}|^2$, and high-set direction-curvature coercivity $|\nabla\hat{\xi}(x_{\max})|^2 \ge c_{\mathrm{dir}}M$ holds, the maximum vorticity rate satisfies $M'(t) \le C_{\mathrm{CZ}}M(t)^2 - (\nu c_{\mathrm{dir}})M(t)^3$, which forces the uniform Lyapunov ceiling $M(t) \le \max(M(0), C_{\mathrm{CZ}}/(\nu c_{\mathrm{dir}}))$; and **(Q₅)** whenever a periodic flow class satisfies the high-set direction-curvature depletion hypothesis $\mathrm{PeriodicDirectionDepletionBound}(\nu)$ and classical periodic Beale–Kato–Majda continuation $\mathrm{PeriodicBKMContinuation}(\nu)$, Fefferman's periodic statement $\mathrm{Clay\_B\_exact}(\nu)$ holds.

### 2. Exact Mathematical Product Form ($Q_1(\nu) \wedge Q_2 \wedge Q_3 \wedge Q_4 \wedge Q_5(\nu)$)
$$\begin{aligned}
\mathcal{Q}_{\mathrm{ClayB}}(\nu) \;\;:\Longleftrightarrow\;\;
&\underbrace{\Bigl(\bigl(\forall f:\mathbb{R}^3\to\mathbb{R}^3,\; \mathrm{IsZ3Periodic}(f) \iff \forall x,\, j\in\{1,2,3\},\; f(x+e_j)=f(x)\bigr) \;\wedge\; \bigl(\mathrm{Clay\_B\_exact\_with\_energy}(\nu) \implies \mathrm{Clay\_B\_exact}(\nu)\bigr)\Bigr)}_{Q_1(\nu):\;\text{Exact Fefferman Periodic Unit-Shift Equivalence \& Energy Implication}} \\
&\wedge\; \underbrace{\Bigl(\bigl(\forall L:\mathbb{R}^3\to_{\mathbb{R}}\mathbb{R}^3,\; \mathrm{IsZ3Periodic}(L) \implies L=0\bigr) \;\wedge\; \bigl(\forall \alpha\neq 0,\; \neg\mathrm{IsZ3Periodic}(\mathrm{diag}(-\tfrac{\alpha}{2},-\tfrac{\alpha}{2},\alpha))\bigr)\Bigr)}_{Q_2:\;\text{Torus Exclusion of Global Linear Burgers Strain}} \\
&\wedge\; \underbrace{\Bigl(\det(\omega_y,z,\omega_x)=\det(\omega_y-\omega_x,z,\omega_x) \;\wedge\; \det(c\omega_x,z,\omega_x)=0 \;\wedge\; C_{\mathrm{CZ}}(\lambda^2|\omega|)^3 - \nu(\lambda^2|\omega|)^2(\lambda|\nabla\hat{\xi}|)^2 = \lambda^6\bigl(C_{\mathrm{CZ}}|\omega|^3 - \nu|\omega|^2|\nabla\hat{\xi}|^2\bigr)\Bigr)}_{Q_3:\;\text{Biot–Savart Alignment Depletion \& }\lambda^6\text{ Parabolic Scaling Homogeneity}} \\
&\wedge\; \underbrace{\Bigl(\bigl(\mathrm{Stretch}\le C_{\mathrm{CZ}}M^3 \wedge \mathrm{Diff}\le -\nu M^2|\nabla\hat{\xi}|^2 \wedge |\nabla\hat{\xi}|^2\ge c_{\mathrm{dir}}M \implies M'\le C_{\mathrm{CZ}}M^2 - \nu c_{\mathrm{dir}}M^3\bigr) \;\wedge\; \bigl(M'\le C_{\mathrm{CZ}}M^2 - \kappa'' M^3 \implies M(t)\le\max(M(0),\tfrac{C_{\mathrm{CZ}}}{\kappa''})\bigr)\Bigr)}_{Q_4:\;\text{Spatial-Maximum Bochner–Polar Reduction \& Cubic ODE Ceiling}} \\
&\wedge\; \underbrace{\Bigl(\bigl(\mathrm{PeriodicDirectionDepletionBound}(\nu) \;\wedge\; \mathrm{PeriodicBKMContinuation}(\nu)\bigr) \implies \mathrm{Clay\_B\_exact}(\nu)\Bigr)}_{Q_5(\nu):\;\text{Exact Conditional Implication to Fefferman's }\mathrm{Clay\_B\_exact}(\nu)}.
\end{aligned}$$

---

## Scope & Scientific Honesty Notice

The named `Prop` `NavierStokes3D.PointwiseStrainSupBound u ω C x` (`Defs.lean`, $\|\nabla u(x)\|\le C\|\omega\|_\infty$) is false in general: Calderón–Zygmund fails at $p=\infty$. `strain_sup_le_of_CZ`, `convective_norm_le_of_CZ`, `stretching_inner_le`, `stretching_inner_le_at_max` and `stretching_quartic_le` take it as a hypothesis, so they are conditional on a bound that is false in general.

This repository has `0 sorry` and `0 custom axioms`. Q₁–Q₃ are unconditional; Q₄ and Q₅ are conditional on the hypotheses stated in them:
1. **Why Unmodified Fefferman Clay (B) Requires an Explicit Direction-Curvature Hypothesis in Lean's Kernel:** For the unmodified Navier–Stokes PDE ($\kappa = 0$ in the dynamics), Lean's kernel derives $\langle \omega, (\omega\cdot\nabla)u\rangle + \nu\langle\omega,\Delta\omega\rangle \le C_{\mathrm{CZ}}M^3 - (\nu c_{\mathrm{dir}})M^4$ at a spatial maximum (`first_remaining_gap_bochner_polar_damping_at_max` in `FinalProductTheorem.lean`) from the Bochner–Weitzenböck polar decomposition **together with the explicit high-set direction-curvature coercivity hypothesis $|\nabla\hat{\xi}(x_{\max})|^2 \ge c_{\mathrm{dir}} M$**. Whether arbitrary smooth periodic flows on $\mathbb{T}^3$ satisfy `PeriodicDirectionDepletionBound ν` unconditionally remains an **open analytical PDE problem** and is therefore stated as an explicit `Prop` hypothesis in $Q_4$ and $Q_5(\nu)$.
2. **Global vs. Local Linear Strain on $\mathbb{T}^3$:** Theorem $Q_2$ (`z3_periodic_linear_eq_zero` and `burgersLinearStrain_not_z3_periodic`) rules out any non-zero *global* linear background strain $u(x) = Ax$ on $\mathbb{R}^3/\mathbb{Z}^3$; localized stretched vortex structures can still form locally on $\mathbb{T}^3$.

---

## Modules (224 theorem/lemma declarations in source at commit `34e5a7f`, `0 sorry`)

| Module | Declaration | Status | Description |
|---|---|---|---|
| `FinalProductTheorem.lean` | `fefferman_periodic_ns_exact_reduction_product_theorem`, `vorticity_sup_norm_eq_of_isSpatialMax`, `polar_pythagoras_3d_sum`, `bochner_laplacian_3d_identity`, `concrete_bochner_polar_viscous_damping_at_max`, `nonzero_periodic_smooth_solution_exists`, `beltrami_lamb_vector_cross3_zero`, `near_field_stretching_absorbed_by_viscous_direction_damping`, `constantin_fefferman_near_far_cutoff_bridge` | **PROVED (21 theorems; Q₅ conditional on `PeriodicDirectionDepletionBound ν` and `PeriodicBKMContinuation ν`)** | Master 5-conjunct product theorem ($Q_1(\nu) \wedge Q_2 \wedge Q_3 \wedge Q_4 \wedge Q_5(\nu)$), Stage 2 `BddAbove`/`sSup` pinning at attained spatial maxima, Stage 3 concrete 3D vector Bochner & polar Pythagoras identities, Stage 4 non-zero smooth periodic flow inhabitation & Beltrami Lamb-vector vanishing, and Stage 5 Constantin–Fefferman near/far Biot–Savart cutoff bridge. |
| `FeffermanStatements.lean` | `Clay_B_exact ν`, `isZ3Periodic_iff_unit_shifts`, `clay_B_exact_of_with_energy`, `library_huniq_unsatisfiable_at_zero`, `stepField_not_physical`, `repaired_hInt`, `repaired_huniq_at_zero` | **PROVED (Unconditional, 10 theorems)** | Verbatim Lean 4 encoding of Fefferman (2006) Statement (B) on $\mathbb{R}^3/\mathbb{Z}^3$, unit-shift equivalence, energy reduction, and step-jump exclusion. |
| `TorusStrainExclusion.lean` | `z3_periodic_linear_eq_zero`, `burgersLinearStrain_not_z3_periodic`, `biot_savart_det_aligned_eq_zero`, `aligned_vorticity_stretching_integrand_zero`, `biot_savart_det_difference_identity`, `navier_stokes_scaling_homogeneity_deg6`, `unnormalized_quartic_scaling_mismatch` | **PROVED (Unconditional, 19 theorems)** | Global linear strain exclusion on $\mathbb{T}^3$, Biot–Savart direction-difference determinant identity, and $\lambda^6$ parabolic scaling homogeneity. |
| `HighSetDepletionAndBKM.lean` | `unmodified_max_rate_of_cubic_source`, `viscous_direction_dissipation_bridge`, `scale_invariant_cubic_rate_of_direction_coercivity`, `comparison_ode_ceiling`, `periodicTetherClosingBound_of_directionDepletion`, `clay_B_exact_of_periodic_tether_bound`, `clay_B_exact_of_torus_direction_depletion`, `periodicFiniteTimeVorticityBound_of_uniform`, `periodicBKMContinuation_of_finiteTime_scaffold`, `clay_B_exact_of_periodic_finite_time_bound_scaffold`, `periodicFiniteTimeBound_vacuous`, `periodicTstar_eq_top_of_bkm`, `periodicGlobalOfTstarTop`, `clay_B_exact_of_periodic_bkm`, `not_periodicLocalExistenceOriginal`, `not_periodicMaximalSolutionOriginal` | **PROVED (26 theorem/lemma declarations: 24 theorems, 2 lemmas; the `clay_B_exact_of_*` reductions are conditional on their stated hypotheses; `clay_B_exact_of_periodic_bkm` is the one where the open input, `PeriodicBKMIntegrability`, is what yields T* = ⊤)** | Reduction from direction-curvature coercivity to $M' \le C_{\mathrm{CZ}}M^2 - \kappa'' M^3$, first-exit-time ODE ceiling $M(t) \le \max(M(0), C_{\mathrm{CZ}}/\kappa'')$, and conditional reductions to `Clay_B_exact ν`. |
| `MainTheorem.lean` | `clay_reduces_to_direction_curvature_bound` | **PROVED (1 theorem; conditional on `PeriodicBKMContinuation ν` and `DirectionCurvatureBound ν`)** | Reduction of `Clay_B_exact ν` to the named open estimate. |
| `Stage6Calculus.lean` | Bochner and polar Pythagoras from `HasDerivAt`, shear Beltrami mode | **PROVED (Unconditional, 16 theorems)** | Calculus identities along coordinate lines. |
| `Defs.lean` | Foundational 3D Navier–Stokes operators, vorticity, strain, and Sobolev definitions | **PROVED (Unconditional, 131 theorems)** | Complete differential/kinematic infrastructure with zero `sorry`. |

---

## Theorem and lemma counts on current `main`

224 theorem/lemma declarations in source at commit `34e5a7f` (Lean sources unchanged since `4cb2150`); the titan audit reports more because it counts compiled/generated constants. This replaces a stale boxed `AxiomAudit.lean` summary, and corrects a 225 count that had included one comment line in `Defs.lean`.

```text
FeffermanClayNS.Defs: 131
FeffermanClayNS.FeffermanStatements: 10
FeffermanClayNS.FinalProductTheorem: 21
FeffermanClayNS.HighSetDepletionAndBKM: 26
FeffermanClayNS.MainTheorem: 1
FeffermanClayNS.Stage6Calculus: 16
FeffermanClayNS.TorusStrainExclusion: 19
TOTAL: 224
```

Reproducible count (strips `--` line comments and nested `/-` `-/` block comments, then counts `theorem`/`lemma` headers, including after modifiers such as `private`/`protected`/`@[simp]`):

```bash
python3 -c 'import re,pathlib
def strip(s):
    o,i,n=[],0,len(s)
    while i<n:
        if s[i]=="\"":
            o.append(s[i]); i+=1
            while i<n:
                if s[i]=="\\" and i+1<n: o+=[s[i],s[i+1]]; i+=2; continue
                o.append(s[i]); i+=1
                if o[-1]=="\"": break
            continue
        if s[i:i+2]=="/-":
            d=1; i+=2
            while i<n and d:
                if s[i:i+2]=="/-": d+=1; i+=2
                elif s[i:i+2]=="-/": d-=1; i+=2
                else:
                    if s[i]=="\n": o.append("\n")
                    i+=1
            continue
        if s[i:i+2]=="--":
            while i<n and s[i]!="\n": i+=1
            continue
        o.append(s[i]); i+=1
    return "".join(o)
pat=re.compile(r"(?m)^[ \t]*(?:@\[[^\]]*\]\s*)*(?:(?:public|private|protected|noncomputable|unsafe|partial)\s+)*(?:@\[[^\]]*\]\s*)*(?:(?:public|private|protected|noncomputable|unsafe|partial)\s+)*(theorem|lemma)\s+\S+")
tot=0
for p in sorted(pathlib.Path("FeffermanClayNS").glob("*.lean")):
    n=len(pat.findall(strip(p.read_text()))); print(f"{p}: {n}"); tot+=n
print("TOTAL:", tot)'
```

Axiom dependencies of `fefferman_periodic_ns_exact_reduction_product_theorem` remain `[propext, Classical.choice, Quot.sound]`, as recorded in `AxiomAudit.lean`.

---

## Cryptographic Verification & IP Containment Suite (`titan-audit` + `sealguard` + `sentinel-gate`)

1. **`titan-audit` ([DOI: 10.5281/zenodo.23630648](https://doi.org/10.5281/zenodo.23630648)):** In-kernel `Lean.collectAxioms` walker (`AxiomAudit.lean`) and Ed25519-signed attestation ([`audit/report.json`](audit/report.json), [`audit/report.md`](audit/report.md), [`audit/TITAN_AUDIT_CERTIFICATE.json`](audit/TITAN_AUDIT_CERTIFICATE.json)).
2. **`sealguard` ([DOI: 10.5281/zenodo.23631670](https://doi.org/10.5281/zenodo.23631670)):** 4-plane cryptographic Merkle-root provenance and classified parameter containment ([`audit/SEALGUARD_CLASSIFIED_MANIFEST.json`](audit/SEALGUARD_CLASSIFIED_MANIFEST.json), [`PROVENANCE_MERKLE_ROOT.json`](PROVENANCE_MERKLE_ROOT.json)).
3. **`sentinel-gate` ([DOI: 10.5281/zenodo.23632766](https://doi.org/10.5281/zenodo.23632766)):** Deterministic pre-execution policy guardrail receipt embedded in [`ip_pipeline/seal_and_verify.py`](ip_pipeline/seal_and_verify.py).

## Contact

- **Author:** Benjamin Stanley Frohman
- **ORCID:** [0009-0006-7068-3718](https://orcid.org/0009-0006-7068-3718)
- **Email:** `frohmanbenjamin@gmail.com`
- **X / GitHub:** `@Investor0x` / `BenFrohman` (`Bit21`)

## Provenance of Ingredients

Dates below are verified from files in the `NS_Millennium_Proof` git history (first commit 2026-06-19, which imported a snapshot directory `historical/previous_implementations/complete_implementation_2026-05-28/`). No April 2026 file was found in the repositories; earlier dates are not asserted.

| Ingredient | Earliest verified date | Source | Status |
|---|---|---|---|
| Young absorption | 2026-05-28 snapshot | `historical/previous_implementations/complete_implementation_2026-05-28/docs/Frohmanian_Tether_NS_Proof_Conversation_Summary.md` | original scaffolding |
| Cubic majorant / Riccati comparison | 2026-05-28 snapshot | `.../complete_implementation_2026-05-28/Modules/IndependentMajorant.lean`, `Skeleton/PaperOverview.lean` | original scaffolding |
| Frohmanian tether | 2026-05-28 snapshot | `.../complete_implementation_2026-05-28/docs/05_Step_Uniqueness_Proof_Structure.md` | original scaffolding |
| Biot–Savart (mentions) | 2026-05-28 snapshot | `.../complete_implementation_2026-05-28/docs/Phase0_Phase1_Implementation_Plan.md` | original scaffolding |
| Bochner–Weitzenböck | 2026-06-19 (git `236244d`) | `NS_Millennium_Proof/Modules/NS_Equations.lean` | classical (Bochner), pinned and cited; concrete 3D form added Oct 2026 (Grok-assisted scaffolding) |
| Constantin–Fefferman direction depletion | 2026-06-19 (git `236244d`) | `NS_Millennium_Proof/Modules/TetheredLyapunov.lean` | classical (Constantin–Fefferman 1993), pinned and cited |
| Attained max / `BddAbove` guards | 2026-08-27 (git `04eb613`) | Lean sources | added Aug 2026 |
| Polar Pythagoras | 2026-10-28 (git `acf5883`) | `Modules/FinalProductTheorem.lean` stages | added Oct 2026 (Grok-assisted scaffolding) |
| Beltrami (Lamb vector, shear mode) | 2026-10-28 (git `acf5883`) | Stage 4 / `Stage6Calculus.lean` | classical (Beltrami flows), pinned and cited; Lean added Oct 2026 (Grok-assisted scaffolding) |
| Near/far Biot–Savart cutoff bridge | 2026-10-28 (git `acf5883`) | Stage 5 | added Oct 2026 (Grok-assisted scaffolding), after Constantin–Fefferman 1993 |
| Reduction theorem `clay_reduces_to_direction_curvature_bound` | 2026-10-28 | `MainTheorem.lean` | added Oct 2026 (Grok-assisted scaffolding); earlier conditional reductions `clay_B_exact_of_*` predate it |

See [`NAMING.md`](NAMING.md) for the canonical names (Frohmanian Tether Hypothesis, symbol 𝔉𝕋) and the old-name glossary.

## AI Assistance Disclosure

Grok (xAI), via the Grok Bot assistant, provided scaffolding, drafting, and collaboration support on formalization, code, and papers in this repository. Benjamin Stanley Frohman is the sole author: he directed, reviewed, and is responsible for all of the work. Grok is not a coauthor.

## Zenodo archive

- [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.23867489.svg)](https://doi.org/10.5281/zenodo.23867489) Formalizing Fefferman's Official Periodic Navier-Stokes Problem (B) in Lean 4: Global Linear Strain Exclusion on T3, Biot-Savart Direction Depletion Identities, and Conditional Reductions via Beale-Kato-Majda — all versions: [10.5281/zenodo.23867489](https://doi.org/10.5281/zenodo.23867489); latest version: [10.5281/zenodo.23905347](https://doi.org/10.5281/zenodo.23905347)
