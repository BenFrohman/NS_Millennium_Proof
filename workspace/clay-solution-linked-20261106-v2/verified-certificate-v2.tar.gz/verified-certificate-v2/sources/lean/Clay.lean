/-
Copyright (c) 2026 Benjamin Stanley Frohman. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: Benjamin Stanley Frohman
-/

import Mathlib
import Clay.Tether
import Clay.Gaps.BKMIntegral
import Clay.Gaps.RejectedMeasureBound
import Clay.Gaps.HistoryClock
import Clay.Gaps.DirectionAlignment
import Clay.Gaps.TwoDClock
import Clay.Gaps.TwoDPlanar
import Clay.Gaps.MissingInputs
import Clay.Gaps.StretchingIntegral
import Clay.Depletion.GeometricAlignment
import Clay.StatementB
import Clay.Gaps
import Clay.Gaps.ConditionalRiccati
import Clay.Notes.NotBlowup

import Clay.Depletion.SolutionLinkedVortexLines
